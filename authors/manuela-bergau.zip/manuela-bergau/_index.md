---
# Display name
name: Manuela Bergau

# Username (this should match the folder name)
authors:
- manuela-bergau

# Is this the primary user of the site?
superuser: false

# Role/position
role: Researcher

# Organizations/Affiliations
organizations:
- name: Universitätsklinikum Bonn, Klinik für Diagnostische und Interventionelle Radiologie
  url: "https://www.ukbonn.de/radiologie/unser-team/"

# Short bio (displayed in user profile at end of posts)
bio: ""



education:
  courses: 
  - course: M.Sc. in Data Science
    institution: Radboud University, Faculty of Science Nijmegen, the Netherlands
    year: 2023
  - course: B.Sc. in Computing Science
    institution: Radboud University, Faculty of Science Nijmegen, the Netherlands
    year: 2019
    
# Social/Academic Networking
# For available icons, see: https://sourcethemes.com/academic/docs/page-builder/#icons
#   For an email link, use "fas" icon pack, "envelope" icon, and a link in the
#   form "mailto:your-email@example.com" or "#contact" for contact widget.
social:
 - icon: envelope
   icon_pack: fas
   link: 
 - icon: google-scholar
   icon_pack: ai
   link: https://scholar.google.de/
   
# Link to a PDF of your resume/CV from the About widget.
# To enable, copy your resume/CV to `static/files/cv.pdf` and uncomment the lines below.
# - icon: cv
#   icon_pack: ai
#   link: files/cv.pdf

# Enter email to display Gravatar (if Gravatar enabled in Config)
email: ""

# Organizational groups that you belong to (for People widget)
#   Set this to `[]` or comment out if you are not using People widget.
user_groups: 
# - Researchers
- Alumni

---
# Biography
Manuela Bergau is a Researcher at Albarqouni Lab at the University Hospital Bonn under the supervision of Prof. Dr. Shadi Albarqouni.
She obtained her bachelor's degree in Computing Science and master's degree in Data Science at Radboud University, Nijmegen.
During her master's, she joined the Diagnostic Image Analysis Group to work on Natural language processing of radiology reports for lesion detection and leveraging radiology reports for automatic lesion detection in CT scans.
At the Albarqouni Lab she will continue her work on the usage of AI in the medical domain.
