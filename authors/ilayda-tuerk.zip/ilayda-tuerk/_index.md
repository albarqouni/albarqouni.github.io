---

# Display name

name: İlayda Selin Türk



# Username (this should match the folder name)

authors:

- ilayda-tuerk



# Full Name (for SEO)

first_name: İlayda Selin 
last_name: Türk



# Is this the primary user of the site?

superuser: false



# Role/position

role: Master Thesis Student



# Organizations/Affiliations

organizations:

- name: Technical University of Munich, Germany
  url: "https://www.tum.de/"



# Short bio (displayed in user profile at end of posts)

bio: "İlayda is currently pursuing her master's degree in Informatics at the Technical University of Munich, with a specialization in Machine Learning, Computer Vision, Digital Biology and Digital Medicine. She is currently working on her master’s thesis *Investigating Bias in AI Algorithms for Breast Cancer Detection from Mammography Imaging: A Focus on Generalization to Unseen Populations*. Alongside her studies, she is also working as a Data Engineering/Machine Learning Engineering Working Student, focusing on researching and implementing state-of-the-art machine learning methods as well as developing data engineering solutions for efficient data processing and integration. She completed her undergraduate study in Computer Engineering at Cankaya University in Turkey."



interests:

- Machine Learning for Medical Imaging

- Deep Learning

- Computer Vision



education:

  courses:

  - course: M.Sc. Informatics

    institution: Technical University of Munich, Germany

    year: present


  - course: B.Sc. Computer Engineering 

    institution: Cankaya University, Turkey
    
    year: 2020

    

# Social/Academic Networking

# For available icons, see: https://sourcethemes.com/academic/docs/page-builder/#icons

#   For an email link, use "fas" icon pack, "envelope" icon, and a link in the

#   form "mailto:your-email@example.com" or "#contact" for contact widget.

social:

- icon: envelope

  icon_pack: fas

  link: mailto:ilaydaselinturk@gmail.com

# - icon: google-scholar

#   icon_pack: ai

#   link: https://scholar.google.de/
- icon: linkedin
  
  icon_pack: fab

  link: https://www.linkedin.com/in/ilaydaselinturk/


# Link to a PDF of your resume/CV from the About widget.

# To enable, copy your resume/CV to `static/files/cv.pdf` and uncomment the lines below.

# - icon: cv

#   icon_pack: ai

#   link: files/cv.pdf



# Enter email to display Gravatar (if Gravatar enabled in Config)

email: "ilaydaselinturk@gmail.com"



# Organizational groups that you belong to (for People widget)

#   Set this to `[]` or comment out if you are not using People widget.

user_groups: 

# - Principal Investigators

- Researchers




---

# Biography

İlayda is currently pursuing her master's degree in Informatics at the Technical University of Munich, with a specialization in Machine Learning, Computer Vision, Digital Biology and Digital Medicine. She is currently working on her master’s thesis *Investigating Bias in AI Algorithms for Breast Cancer Detection from Mammography Imaging: A Focus on Generalization to Unseen Populations*. Alongside her studies, she is also working as a Data Engineering/Machine Learning Engineering Working Student, focusing on researching and implementing state-of-the-art machine learning methods as well as developing data engineering solutions for efficient data processing and integration. She completed her undergraduate study in Computer Engineering at Cankaya University in Turkey.
