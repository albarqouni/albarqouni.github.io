---
# Display name
name: Shadi Albarqouni  

# Username (this should match the folder name)
authors:
- shadi-albarqouni

# Is this the primary user of the site?
superuser: false

# Role/position
role: AI Young Investigator Group Leader at [Helmholtz AI](https://www.helmholtz.ai/) | TUM Junior Fellow at [TU Munich](https://www.tum.de/) | Former Visiting Scientist at [Imperial College London](https://www.imperial.ac.uk/computing) and [ETH Zürich](https://bmic.ee.ethz.ch/)

# Organizations/Affiliations
organizations:
- name: Helmholtz AI
  url: "https://www.helmholtz.ai/"
- name: Technical University Munich
  url: "https://www.tum.de/"

# Short bio (displayed in user profile at end of posts)
bio: ""

interests:
- Deep Learning with Medical Imaging 
- Representation Learning
- Uncertainty 
- Federated Learning 

education:
  courses:
  - course: Ph.D. in Computer Science 
    institution: Technical University of Munich, Germany
    year: 2017
  - course: M.Sc. in Electrical Engineering
    institution: Islamic University of Gaza, Palestine
    year: 2010
  - course: B.Sc. in Electrical Engineering
    institution: Islamic University of Gaza, Palestine
    year: 2005

# Social/Academic Networking
# For available icons, see: https://sourcethemes.com/academic/docs/page-builder/#icons
#   For an email link, use "fas" icon pack, "envelope" icon, and a link in the
#   form "mailto:your-email@example.com" or "#contact" for contact widget.
social:
- icon: envelope
  icon_pack: fas
  link: "mailto:shadi.albarqouni@tum.de"
- icon: twitter
  icon_pack: fab
  link: https://twitter.com/ShadiAlbarqouni
- icon: google-scholar
  icon_pack: ai
  link: https://scholar.google.de/citations?user=CPuApzoAAAAJ&hl=en
- icon: github
  icon_pack: fab
  link: https://github.com/albarqouni
- icon: linkedin
  icon_pack: fab
  link: https://www.linkedin.com/in/shadialbarqouni/
- icon: orcid
  icon_pack: ai
  link: https://orcid.org/0000-0003-2157-2211
- icon: globe-africa
  icon_pack: fas
  link: https://albarqouni.github.io/

# Link to a PDF of your resume/CV from the About widget.
# To enable, copy your resume/CV to `static/files/cv.pdf` and uncomment the lines below.
# - icon: cv
#   icon_pack: ai
#   link: files/cv.pdf

# Enter email to display Gravatar (if Gravatar enabled in Config)
email: "shadi.albarqouni@tum.de"

# Organizational groups that you belong to (for People widget)
#   Set this to `[]` or comment out if you are not using People widget.
user_groups:
- Senior Affiliated Lecturer

---

Shadi Albarqouni is a Palestinian-German Computer Scientist. He received his B.Sc. and M.Sc. in Electrical Engineering from the IU Gaza, Palestine, in 2005, and 2010, respectively. In 2012, he received a prestigious [DAAD](www.daad.de) research grant to pursue his Ph.D. at the [Chair for Computer Aided Medical Procedures (CAMP)](http://campar.in.tum.de/WebHome), [Technical University of Munich (TUM)](https://www.tum.de/), Germany. During his Ph.D., Albarqouni worked with [Prof. Nassir Navab](https://scholar.google.de/citations?user=kzoVUPYAAAAJ&hl=en) on developing machine learning algorithms to handle noisy labels, coming from crowdsourcing, in medical imaging. Albarqouni received his Ph.D. in Computer Science with *summa cum laude* in 2017.

Since then, Albarqouni has been working as a [Senior Research Scientist & Team Lead](http://campar.in.tum.de/Main/ShadiAlbarqouni) at [CAMP](http://campar.in.tum.de/WebHome) leading the [Medical Image Analysis (MedIA)](http://campar.in.tum.de/Chair/ResearchIssueMedicalImage) team with an emphasis on developing deep learning methods for medical applications. In 2019, he received the [P.R.I.M.E. fellowship](https://www.daad.de/en/study-and-research-in-germany/scholarships/prime-fellows-201819/) for one-year international mobility.  During the period from Nov. 2019 to Jul. 2020, worked as a [Visiting Scientist](https://bmic.ee.ethz.ch/people/person-details.shadi-alberqouni.html) at the [Department of Information Technology and Electrical Engineering (D-ITET)](https://ee.ethz.ch/) at [ETH Zürich](https://ethz.ch/en.html), Switzerland. He worked with [Prof. Ender Konukoglu](http://people.ee.ethz.ch/~kender/) on [Modeling Uncertainty in Medical Imaging](project/uncertainty/), in particular, the one associated with inter-/intra-raters variability. During the period Aug.-Oct. 2020, Albarqouni worked as a Visting Scientist at the [Department of Computing](https://www.imperial.ac.uk/computing) at [Imperial College London](http://www.imperial.ac.uk/), United Kingdom. He worked with [Prof. Daniel Rueckert](http://wp.doc.ic.ac.uk/dr/) on [Federated Learning](project/federated-learning). 

Since Nov. 2020, Albarqouni is holding an [AI Young Investigator Group Leader](https://www.helmholtz.ai/themenmenue/our-research/research-groups/albarqounis-group/index.html) position at [Helmholtz AI](https://www.helmholtz.ai/).  The aim of Albarqouni Lab is to develop innovative deep [Federated Learning](project/federated-learning) algorithms that can distill and share the knowledge among AI agents in a robust and privacy-preserved fashion. 

Albarqouni has around 100 peer-reviewed publications in both Medical Imaging Computing and Computer Vision published in high impacted journals and top-tier conferences. He serves as a reviewer for many journals, *e.g.*, [IEEE TPAMI](https://www.computer.org/csdl/journal/tp), [MedIA](https://www.journals.elsevier.com/medical-image-analysis), [IEEE TMI](https://www.embs.org/tmi/), [IEEE JBHI](https://www.embs.org/jbhi/), [IJCARS](https://www.springer.com/journal/11548) and [Pattern Recognition](https://www.journals.elsevier.com/pattern-recognition), and top-tier conferences, *e.g.,* [ECCV](https://eccv2020.eu/), [MICCAI](https://www.miccai2020.org/en/), [MIDL](https://2020.midl.io/), [BMVC](https://britishmachinevisionassociation.github.io/bmvc), [IPCAI](http://www.ipcai.org/), and [ISBI](http://2020.biomedicalimaging.org/) among others. He is also an active member of [ELLIS](https://ellis.eu/members), [AGYA](http://www.agya.info/), [MICCAI](http://www.miccai.org/members), [BMVA](http://www.bmva.org/), [IEEE EMBS](https://www.ieee.org/membership-catalog/productdetail/showProductDetailPage.html?product=MEMEMB018), [IEEE CS](https://www.ieee.org/membership-catalog/productdetail/showProductDetailPage.html?product=MEMC016), and [ESR](https://www.myesr.org/) society. Since 2015, he has been serving as a PC member for a couple of MICCAI workshops, *e.g.*, [COMPAY](https://compay19.grand-challenge.org/organizers/), and [DART](https://sites.google.com/view/dart2020/organization) among others. Since 2019, Albarqouni has been serving as an [Area Chair](https://www.miccai2019.org/committee/) in Advance Machine Learning Theory at [MICCAI](http://www.miccai.org/). 

His current research interests include Interpretable ML, Robustness, Uncertainty, and recently Federated Learning. He is also interested in Entrepreneurship and Startups for Innovative Medical Solutions. 