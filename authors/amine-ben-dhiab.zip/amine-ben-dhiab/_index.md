---
# Display name
name: Amine Ben Dhiab

# Username (this should match the folder name)
authors:
- amine-ben-dhiab

# Full Name (for SEO)
first_name: Amine
last_name: Ben Dhiab

# Is this the primary user of the site?
superuser: false

# Role/position
role: Master Thesis Student

# Organizations/Affiliations
organizations:
- name: Technical University of Munich, Germany
  url: "https://www.tum.de"

# Short bio (displayed in user profile at end of posts)
bio: "Amine Ben Dhiab is a Master's student in Robotics, Cognition and Intelligence at TUM, currently pursuing his master's thesis at the University of Bonn under the supervision of Prof. Dr. Shadi Albarqouni. His interests lie in AI in medicine, machine learning, computer vision, and multimodal learning, with project experience in medical imaging, vision-language modeling, and clinical NLP."

education:
  courses:
  - course: M.Sc. Robotics, Cognition and Intelligence
    institution: Technical University of Munich, Germany
    year: 2026

  - course: B.Sc. Electrical Engineering and Information Technology
    institution: Technical University of Munich, Germany
    year: 2022

# Social/Academic Networking
social:
- icon: envelope
  icon_pack: fas
  link: "mailto:amine.ben-dhiab@tum.de"
- icon: github
  icon_pack: fab
  link: "https://github.com/AmineBDhiab"
- icon: linkedin
  icon_pack: fab
  link: "https://www.linkedin.com/in/amine-ben-dhiab/"

# Link to a PDF of your resume/CV from the About widget.
# To enable, copy your resume/CV to `static/files/cv.pdf` and uncomment the lines below.
# - icon: cv
#   icon_pack: ai
#   link: files/cv.pdf

# Enter email to display Gravatar (if Gravatar enabled in Config)
email: "amine.ben-dhiab@tum.de"

# Organizational groups that you belong to (for People widget)
user_groups:
- Researchers

---
# Biography
Amine Ben Dhiab is a Master's student in Robotics, Cognition and Intelligence at the Technical University of Munich (TUM), currently pursuing his master's thesis at the University of Bonn under the supervision of Prof. Dr. Shadi Albarqouni.

His work focuses on AI in medicine, machine learning, computer vision, and multimodal learning. He has worked on projects in medical imaging, vision-language modeling, graph-based learning, and clinical natural language processing.

His recent work includes MRI-based intervertebral disc degeneration analysis, biomedical vision-language modeling, and LLM-based structuring of radiology reports. He is interested in building robust and clinically relevant AI systems for healthcare.
