---
# Display name
name: Baraa Hassan

# Username (this should match the folder name)
authors:
- baraa-hassan

# Is this the primary user of the site?
superuser: false

# Role/position
role: Researcher

# Organizations/Affiliations
organizations:
- name: University Hospital Bonn 
  url: "ukb.uni-bonn.de"

# Short bio (displayed in user profile at end of posts)
bio: "Baraa Hassan is a Master’s graduate in Computer Science at the University of Bonn and the father of Younus. He spent 2 years in the industry as a Software Engineer before pursuing his Master’s Degree. He also has been a contestant in the national version of the ACM ICPC between 2012 and 2015. Also, he was working as a Research Assistant during his Master’s degree. Baraa pursued Computer Science from the beginning because of his love of Mathematics and Problem Solving. During his career, he enjoyed solving challenging problems, interacting with colleagues, and learning new things every day. Some projects that he worked on are Upgrading the prepaid system of the EEH company, Anticipating Human Behavior, and IntelliLung (using Deep Reinforcement Learning to support patients in the ICU). Additionally, he has been a fundraiser for many student activities (at Ain Shams University), an organizer of a Computer Vision reading group (at Uni Bonn), and the Leader of the Reinforcement Learning reading group (at InfAI). He is also a member of different Machine Learning communities (e.g. ML Collectives, Black in AI, and CORDAI). Besides the technical side, Baraa has different hobbies such as dubbing, swimming, riding horses, reading, acting, performing stand-up shows, and writing funny scripts. He was a member (Voice Over and Script Writer) of a Facebook Page that converts well-known scenes from animation movies into a local dialect. Currently, Baraa is a Research Assistant in Albarqouni Lab at the University Hospital Bonn. He is working under the supervision of Prof. Dr. Shadi Albarqouni on the topic of Robust and Interpretable Machine Learning in Medical Imaging."

interests:
- Machine Learning in Medical Imaging
- Self-Supervised Learning
- Robust Machine Learning
- Interpretable Machine Learning
- Reinforcment Learning

education:
  courses:
  - course: M.Sc. in Computer Science 
    institution: University of Bonn, Germany
    year: 2022
  - course: B.Sc. in Computer Science
    institution: Ain Shams University, Egypt
    year: 2016

# Social/Academic Networking
# For available icons, see: https://sourcethemes.com/academic/docs/page-builder/#icons
#   For an email link, use "fas" icon pack, "envelope" icon, and a link in the
#   form "mailto:your-email@example.com" or "#contact" for contact widget.
social:
- icon: envelope
  icon_pack: fas
  link: 
- icon: google-scholar
  icon_pack: ai
  link: 
- icon: linkedin
  icon_pack: fab
  link: https://www.linkedin.com/in/baraa-hassan-9899688a/
- icon: twitter
  icon_pack: fab
  link: https://twitter.com/bezy92

# Link to a PDF of your resume/CV from the About widget.
# To enable, copy your resume/CV to `static/files/cv.pdf` and uncomment the lines below.
# - icon: cv
#   icon_pack: ai
#   link: files/cv.pdf

# Enter email to display Gravatar (if Gravatar enabled in Config)
email: ""

# Organizational groups that you belong to (for People widget)
#   Set this to `[]` or comment out if you are not using People widget.
user_groups: 
- Researchers

---
# Biography

Baraa Hassan is a Master’s graduate in Computer Science at the University of Bonn and the father of Younus. He spent 2 years in the industry as a Software Engineer before pursuing his Master’s Degree. He also has been a contestant in the national version of the ACM ICPC between 2012 and 2015. Also, he was working as a Research Assistant during his Master’s degree. Baraa pursued Computer Science from the beginning because of his love of Mathematics and Problem Solving. During his career, he enjoyed solving challenging problems, interacting with colleagues, and learning new things every day. Some projects that he worked on are Upgrading the prepaid system of the EEH company, Anticipating Human Behavior, and IntelliLung (using Deep Reinforcement Learning to support patients in the ICU). Additionally, he has been a fundraiser for many student activities (at Ain Shams University), an organizer of a Computer Vision reading group (at Uni Bonn), and the Leader of the Reinforcement Learning reading group (at InfAI). He is also a member of different Machine Learning communities (e.g. ML Collectives, Black in AI, and CORDAI). Besides the technical side, Baraa has different hobbies such as dubbing, swimming, riding horses, reading, acting, performing stand-up shows, and writing funny scripts. He was a member (Voice Over and Script Writer) of a Facebook Page that converts well-known scenes from animation movies into a local dialect. Currently, Baraa is a Research Assistant in Albarqouni Lab at the University Hospital Bonn. He is working under the supervision of Prof. Dr. Shadi Albarqouni on the topic of Robust and Interpretable Machine Learning in Medical Imaging.
